﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'tr', {
	btn_about: 'SCAYT\'ı hakkında',
	btn_dictionaries: 'Sözlükler',
	btn_disable: 'SCAYT\'ı pasifleştir',
	btn_enable: 'SCAYT\'ı etkinleştir',
	btn_langs:'Diller',
	btn_options: 'Seçenekler',
	text_title:  'Girmiş olduğunuz kelime denetimi'
});