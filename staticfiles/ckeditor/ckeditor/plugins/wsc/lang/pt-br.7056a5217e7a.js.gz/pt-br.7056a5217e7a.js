﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'pt-br', {
	btnIgnore: 'Ignorar uma vez',
	btnIgnoreAll: 'Ignorar Todas',
	btnReplace: 'Alterar',
	btnReplaceAll: 'Alterar Todas',
	btnUndo: 'Desfazer',
	changeTo: 'Alterar para',
	errorLoading: 'Erro carregando servidor de aplicação: %s.',
	ieSpellDownload: 'A verificação ortográfica não foi instalada. Você gostaria de realizar o download agora?',
	manyChanges: 'Verificação ortográfica encerrada: %1 palavras foram alteradas',
	noChanges: 'Verificação ortográfica encerrada: Não houve alterações',
	noMispell: 'Verificação encerrada: Não foram encontrados erros de ortografia',
	noSuggestions: '-sem sugestões de ortografia-',
	notAvailable: 'Desculpe, o serviço não está disponível no momento.',
	notInDic: 'Não encontrada',
	oneChange: 'Verificação ortográfica encerrada: Uma palavra foi alterada',
	progress: 'Verificação ortográfica em andamento...',
	title: 'Corretor Ortográfico',
	toolbar: 'Verificar Ortografia'
});
