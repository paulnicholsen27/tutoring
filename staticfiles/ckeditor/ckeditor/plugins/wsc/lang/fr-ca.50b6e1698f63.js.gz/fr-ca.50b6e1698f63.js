﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'fr-ca', {
	btnIgnore: 'Ignorer',
	btnIgnoreAll: 'Ignorer tout',
	btnReplace: 'Remplacer',
	btnReplaceAll: 'Remplacer tout',
	btnUndo: 'Annuler',
	changeTo: 'Changer en',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Le Correcteur d\'orthographe n\'est pas installé. Souhaitez-vous le télécharger maintenant?',
	manyChanges: 'Vérification d\'orthographe terminée: %1 mots modifiés',
	noChanges: 'Vérification d\'orthographe terminée: Pas de modifications',
	noMispell: 'Vérification d\'orthographe terminée: pas d\'erreur trouvée',
	noSuggestions: '- Pas de suggestion -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Pas dans le dictionnaire',
	oneChange: 'Vérification d\'orthographe terminée: Un mot modifié',
	progress: 'Vérification d\'orthographe en cours...',
	title: 'Spell Checker',
	toolbar: 'Orthographe'
});
